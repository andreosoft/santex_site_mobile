export const Number = () => import('../../components/number.vue' /* webpackChunkName: "components/number" */).then(c => wrapFunctional(c.default || c))
export const BlogCarusel = () => import('../../components/blog/carusel.vue' /* webpackChunkName: "components/blog-carusel" */).then(c => wrapFunctional(c.default || c))
export const CatalogAvailable = () => import('../../components/catalog/available.vue' /* webpackChunkName: "components/catalog-available" */).then(c => wrapFunctional(c.default || c))
export const CatalogBaseCatalog = () => import('../../components/catalog/base-catalog.vue' /* webpackChunkName: "components/catalog-base-catalog" */).then(c => wrapFunctional(c.default || c))
export const CatalogBrands = () => import('../../components/catalog/brands.vue' /* webpackChunkName: "components/catalog-brands" */).then(c => wrapFunctional(c.default || c))
export const CatalogCheck1 = () => import('../../components/catalog/check1.vue' /* webpackChunkName: "components/catalog-check1" */).then(c => wrapFunctional(c.default || c))
export const CatalogComplectBlock = () => import('../../components/catalog/complect-block.vue' /* webpackChunkName: "components/catalog-complect-block" */).then(c => wrapFunctional(c.default || c))
export const CatalogFilter = () => import('../../components/catalog/filter.vue' /* webpackChunkName: "components/catalog-filter" */).then(c => wrapFunctional(c.default || c))
export const CatalogFilterResult = () => import('../../components/catalog/filterResult.vue' /* webpackChunkName: "components/catalog-filter-result" */).then(c => wrapFunctional(c.default || c))
export const CatalogItemListCollection = () => import('../../components/catalog/item-list-collection.vue' /* webpackChunkName: "components/catalog-item-list-collection" */).then(c => wrapFunctional(c.default || c))
export const CatalogItemListCompare = () => import('../../components/catalog/item-list-compare.vue' /* webpackChunkName: "components/catalog-item-list-compare" */).then(c => wrapFunctional(c.default || c))
export const CatalogItemListSmallType2 = () => import('../../components/catalog/item-list-small-type-2.vue' /* webpackChunkName: "components/catalog-item-list-small-type2" */).then(c => wrapFunctional(c.default || c))
export const CatalogItemListSmall = () => import('../../components/catalog/item-list-small.vue' /* webpackChunkName: "components/catalog-item-list-small" */).then(c => wrapFunctional(c.default || c))
export const CatalogItemListTail = () => import('../../components/catalog/item-list-tail.vue' /* webpackChunkName: "components/catalog-item-list-tail" */).then(c => wrapFunctional(c.default || c))
export const CatalogItemList = () => import('../../components/catalog/item-list.vue' /* webpackChunkName: "components/catalog-item-list" */).then(c => wrapFunctional(c.default || c))
export const CatalogNumberRange = () => import('../../components/catalog/numberRange.vue' /* webpackChunkName: "components/catalog-number-range" */).then(c => wrapFunctional(c.default || c))
export const CatalogPrice = () => import('../../components/catalog/price.vue' /* webpackChunkName: "components/catalog-price" */).then(c => wrapFunctional(c.default || c))
export const CatalogRanges = () => import('../../components/catalog/ranges.vue' /* webpackChunkName: "components/catalog-ranges" */).then(c => wrapFunctional(c.default || c))
export const CatalogTopBar = () => import('../../components/catalog/top-bar.vue' /* webpackChunkName: "components/catalog-top-bar" */).then(c => wrapFunctional(c.default || c))
export const CatalogTopSelect = () => import('../../components/catalog/top-select.vue' /* webpackChunkName: "components/catalog-top-select" */).then(c => wrapFunctional(c.default || c))
export const FavoriteItemListSmall = () => import('../../components/favorite/item-list-small.vue' /* webpackChunkName: "components/favorite-item-list-small" */).then(c => wrapFunctional(c.default || c))
export const FavoriteItemList = () => import('../../components/favorite/item-list.vue' /* webpackChunkName: "components/favorite-item-list" */).then(c => wrapFunctional(c.default || c))
export const IndexCatalogItems = () => import('../../components/index/catalogItems.vue' /* webpackChunkName: "components/index-catalog-items" */).then(c => wrapFunctional(c.default || c))
export const IndexCatalogItemsEl = () => import('../../components/index/catalogItemsEl.vue' /* webpackChunkName: "components/index-catalog-items-el" */).then(c => wrapFunctional(c.default || c))
export const IndexGuideStyleItems = () => import('../../components/index/guideStyleItems.vue' /* webpackChunkName: "components/index-guide-style-items" */).then(c => wrapFunctional(c.default || c))
export const IndexMainCarusel = () => import('../../components/index/mainCarusel.vue' /* webpackChunkName: "components/index-main-carusel" */).then(c => wrapFunctional(c.default || c))
export const IndexMainInfoBlock = () => import('../../components/index/mainInfoBlock.vue' /* webpackChunkName: "components/index-main-info-block" */).then(c => wrapFunctional(c.default || c))
export const IndexNewItems = () => import('../../components/index/newItems.vue' /* webpackChunkName: "components/index-new-items" */).then(c => wrapFunctional(c.default || c))
export const IndexNewItemsEl = () => import('../../components/index/newItemsEl.vue' /* webpackChunkName: "components/index-new-items-el" */).then(c => wrapFunctional(c.default || c))
export const IndexNewItemsElCarusel = () => import('../../components/index/newItemsElCarusel.vue' /* webpackChunkName: "components/index-new-items-el-carusel" */).then(c => wrapFunctional(c.default || c))
export const IndexSalesItems = () => import('../../components/index/salesItems.vue' /* webpackChunkName: "components/index-sales-items" */).then(c => wrapFunctional(c.default || c))
export const IndexVideo = () => import('../../components/index/video.vue' /* webpackChunkName: "components/index-video" */).then(c => wrapFunctional(c.default || c))
export const CommonBeadcrumbs = () => import('../../components/common/beadcrumbs.vue' /* webpackChunkName: "components/common-beadcrumbs" */).then(c => wrapFunctional(c.default || c))
export const CommonCarusel = () => import('../../components/common/carusel.vue' /* webpackChunkName: "components/common-carusel" */).then(c => wrapFunctional(c.default || c))
export const CommonCatalogMenu = () => import('../../components/common/catalog-menu.vue' /* webpackChunkName: "components/common-catalog-menu" */).then(c => wrapFunctional(c.default || c))
export const CommonDivider1 = () => import('../../components/common/divider1.vue' /* webpackChunkName: "components/common-divider1" */).then(c => wrapFunctional(c.default || c))
export const CommonFooter = () => import('../../components/common/footer.vue' /* webpackChunkName: "components/common-footer" */).then(c => wrapFunctional(c.default || c))
export const CommonHeader = () => import('../../components/common/header.vue' /* webpackChunkName: "components/common-header" */).then(c => wrapFunctional(c.default || c))
export const CommonImageGallery = () => import('../../components/common/imageGallery.vue' /* webpackChunkName: "components/common-image-gallery" */).then(c => wrapFunctional(c.default || c))
export const CommonPagination = () => import('../../components/common/pagination.vue' /* webpackChunkName: "components/common-pagination" */).then(c => wrapFunctional(c.default || c))
export const CommonTop = () => import('../../components/common/top.vue' /* webpackChunkName: "components/common-top" */).then(c => wrapFunctional(c.default || c))
export const CommonVideo = () => import('../../components/common/video.vue' /* webpackChunkName: "components/common-video" */).then(c => wrapFunctional(c.default || c))
export const PagesAbout = () => import('../../components/pages/about.vue' /* webpackChunkName: "components/pages-about" */).then(c => wrapFunctional(c.default || c))
export const PagesContacts = () => import('../../components/pages/contacts.vue' /* webpackChunkName: "components/pages-contacts" */).then(c => wrapFunctional(c.default || c))
export const PagesDelivery = () => import('../../components/pages/delivery.vue' /* webpackChunkName: "components/pages-delivery" */).then(c => wrapFunctional(c.default || c))
export const PagesGaranty = () => import('../../components/pages/garanty.vue' /* webpackChunkName: "components/pages-garanty" */).then(c => wrapFunctional(c.default || c))
export const PagesPayment = () => import('../../components/pages/payment.vue' /* webpackChunkName: "components/pages-payment" */).then(c => wrapFunctional(c.default || c))
export const SGuideStyleItems = () => import('../../components/s/guideStyleItems.vue' /* webpackChunkName: "components/s-guide-style-items" */).then(c => wrapFunctional(c.default || c))
export const SGuideStyleItemsEl = () => import('../../components/s/guideStyleItemsEl.vue' /* webpackChunkName: "components/s-guide-style-items-el" */).then(c => wrapFunctional(c.default || c))
export const SHeader = () => import('../../components/s/header.vue' /* webpackChunkName: "components/s-header" */).then(c => wrapFunctional(c.default || c))
export const SPopupBuyoneclick = () => import('../../components/s/popupBuyoneclick.vue' /* webpackChunkName: "components/s-popup-buyoneclick" */).then(c => wrapFunctional(c.default || c))
export const SPopupConsult = () => import('../../components/s/popupConsult.vue' /* webpackChunkName: "components/s-popup-consult" */).then(c => wrapFunctional(c.default || c))
export const SPopupConsultShowroom = () => import('../../components/s/popupConsultShowroom.vue' /* webpackChunkName: "components/s-popup-consult-showroom" */).then(c => wrapFunctional(c.default || c))
export const SSelectCity = () => import('../../components/s/selectCity.vue' /* webpackChunkName: "components/s-select-city" */).then(c => wrapFunctional(c.default || c))
export const STimePicker = () => import('../../components/s/timePicker.vue' /* webpackChunkName: "components/s-time-picker" */).then(c => wrapFunctional(c.default || c))

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
