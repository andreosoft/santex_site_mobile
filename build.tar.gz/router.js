import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _2ddfeaff = () => interopDefault(import('../pages/acceptRules.vue' /* webpackChunkName: "pages/acceptRules" */))
const _963a9f20 = () => interopDefault(import('../pages/allcategories/index.vue' /* webpackChunkName: "pages/allcategories/index" */))
const _76dd8225 = () => interopDefault(import('../pages/blog/index.vue' /* webpackChunkName: "pages/blog/index" */))
const _1653984b = () => interopDefault(import('../pages/brends/index.vue' /* webpackChunkName: "pages/brends/index" */))
const _8067efba = () => interopDefault(import('../pages/cart/index.vue' /* webpackChunkName: "pages/cart/index" */))
const _29b81fd6 = () => interopDefault(import('../pages/compare.vue' /* webpackChunkName: "pages/compare" */))
const _25924ff9 = () => interopDefault(import('../pages/consulting/index.vue' /* webpackChunkName: "pages/consulting/index" */))
const _b0a361ca = () => interopDefault(import('../pages/designers/index.vue' /* webpackChunkName: "pages/designers/index" */))
const _d6ce93c8 = () => interopDefault(import('../pages/favorite.vue' /* webpackChunkName: "pages/favorite" */))
const _5d53cd38 = () => interopDefault(import('../pages/privacy.vue' /* webpackChunkName: "pages/privacy" */))
const _3f1801a3 = () => interopDefault(import('../pages/publicOffer.vue' /* webpackChunkName: "pages/publicOffer" */))
const _a93182a2 = () => interopDefault(import('../pages/userAgreement.vue' /* webpackChunkName: "pages/userAgreement" */))
const _4ed26ec2 = () => interopDefault(import('../pages/cart/order.vue' /* webpackChunkName: "pages/cart/order" */))
const _86014116 = () => interopDefault(import('../pages/catalog/getData.js' /* webpackChunkName: "pages/catalog/getData" */))
const _1c098769 = () => interopDefault(import('../pages/catalog/promotions/index.vue' /* webpackChunkName: "pages/catalog/promotions/index" */))
const _65e8c43e = () => interopDefault(import('../pages/catalog/search/index.vue' /* webpackChunkName: "pages/catalog/search/index" */))
const _d7c0754a = () => interopDefault(import('../pages/catalog/search/notfind.vue' /* webpackChunkName: "pages/catalog/search/notfind" */))
const _bc81e64a = () => interopDefault(import('../pages/catalog/collection/view/_id.vue' /* webpackChunkName: "pages/catalog/collection/view/_id" */))
const _53ec044b = () => interopDefault(import('../pages/catalog/tile/view/_id.vue' /* webpackChunkName: "pages/catalog/tile/view/_id" */))
const _68d9187f = () => interopDefault(import('../pages/catalog/collection/_id.vue' /* webpackChunkName: "pages/catalog/collection/_id" */))
const _1c6b3b0f = () => interopDefault(import('../pages/catalog/tile/_id.vue' /* webpackChunkName: "pages/catalog/tile/_id" */))
const _2ac787f4 = () => interopDefault(import('../pages/catalog/view/_id.vue' /* webpackChunkName: "pages/catalog/view/_id" */))
const _bde3d94a = () => interopDefault(import('../pages/allcategories/_id/index.vue' /* webpackChunkName: "pages/allcategories/_id/index" */))
const _55c04b18 = () => interopDefault(import('../pages/catalog/_id.vue' /* webpackChunkName: "pages/catalog/_id" */))
const _03a32ddb = () => interopDefault(import('../pages/interior/_id.vue' /* webpackChunkName: "pages/interior/_id" */))
const _6d3f15c2 = () => interopDefault(import('../pages/pages/_id.vue' /* webpackChunkName: "pages/pages/_id" */))
const _7457b31b = () => interopDefault(import('../pages/promote/_id.vue' /* webpackChunkName: "pages/promote/_id" */))
const _816bf8fc = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/acceptRules",
    component: _2ddfeaff,
    name: "acceptRules"
  }, {
    path: "/allcategories",
    component: _963a9f20,
    name: "allcategories"
  }, {
    path: "/blog",
    component: _76dd8225,
    name: "blog"
  }, {
    path: "/brends",
    component: _1653984b,
    name: "brends"
  }, {
    path: "/cart",
    component: _8067efba,
    name: "cart"
  }, {
    path: "/compare",
    component: _29b81fd6,
    name: "compare"
  }, {
    path: "/consulting",
    component: _25924ff9,
    name: "consulting"
  }, {
    path: "/designers",
    component: _b0a361ca,
    name: "designers"
  }, {
    path: "/favorite",
    component: _d6ce93c8,
    name: "favorite"
  }, {
    path: "/privacy",
    component: _5d53cd38,
    name: "privacy"
  }, {
    path: "/publicOffer",
    component: _3f1801a3,
    name: "publicOffer"
  }, {
    path: "/userAgreement",
    component: _a93182a2,
    name: "userAgreement"
  }, {
    path: "/cart/order",
    component: _4ed26ec2,
    name: "cart-order"
  }, {
    path: "/catalog/getData",
    component: _86014116,
    name: "catalog-getData"
  }, {
    path: "/catalog/promotions",
    component: _1c098769,
    name: "catalog-promotions"
  }, {
    path: "/catalog/search",
    component: _65e8c43e,
    name: "catalog-search"
  }, {
    path: "/catalog/search/notfind",
    component: _d7c0754a,
    name: "catalog-search-notfind"
  }, {
    path: "/catalog/collection/view/:id?",
    component: _bc81e64a,
    name: "catalog-collection-view-id"
  }, {
    path: "/catalog/tile/view/:id?",
    component: _53ec044b,
    name: "catalog-tile-view-id"
  }, {
    path: "/catalog/collection/:id?",
    component: _68d9187f,
    name: "catalog-collection-id"
  }, {
    path: "/catalog/tile/:id?",
    component: _1c6b3b0f,
    name: "catalog-tile-id"
  }, {
    path: "/catalog/view/:id?",
    component: _2ac787f4,
    name: "catalog-view-id"
  }, {
    path: "/allcategories/:id",
    component: _bde3d94a,
    name: "allcategories-id"
  }, {
    path: "/catalog/:id?",
    component: _55c04b18,
    name: "catalog-id"
  }, {
    path: "/interior/:id?",
    component: _03a32ddb,
    name: "interior-id"
  }, {
    path: "/pages/:id?",
    component: _6d3f15c2,
    name: "pages-id"
  }, {
    path: "/promote/:id?",
    component: _7457b31b,
    name: "promote-id"
  }, {
    path: "/",
    component: _816bf8fc,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
